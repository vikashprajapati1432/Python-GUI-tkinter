

==========        Small  Description about the project      ==============

The project name is Restaurent Management System using python.
You can add items like Drinks and Foods.
Get the total amount of Drinks and Foods.
Get the bill of the service charged, paid tax, and atlast get the total bills include service charged, tax and drinks and food you order.
In this project a small calculator where you can calculate simple operations.
In this project you can save the bill receipt , send the bill on your mobile phone.

=======================================================

================== Features of the project ==================

1. Get the total cost of drinks & foods seprate
2. Get the total bill include with tax charges and service charges.
3. A small feature of calculator and perform some simple task.
4. You can save the reciept of the bill.
5. You can send the bill on your mobile phone.
6. Reset all the bill
7. Great Validation on this application.
8. Exit Features in the application.

======================================================

===============        SMS Feature   ==========================

To get the sms feature on this project where you can send bill on your mobile number through sms.
Go the offical website of           www.fast2sms.com          and signup here to get the free api.
copy the api and paste in  api variable in a  send() function code..

=====================================================

--------------------------------------------------------------------------------------------------------------
